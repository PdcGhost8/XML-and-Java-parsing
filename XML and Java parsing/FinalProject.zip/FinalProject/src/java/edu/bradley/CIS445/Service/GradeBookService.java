/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.bradley.CIS445.Service;

import edu.bradley.CIS445.Assignment;
import edu.bradley.CIS445.Course;
import edu.bradley.CIS445.Student;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author pdc49_000
 */
@WebService(serviceName = "GradeBookService")
@Stateless()
public class GradeBookService {

    
    Course tmp = new Course("tst"); 
    /**
     * This is a sample web service operation
     */
    /*
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    */
    
    //or use constructor
   public GradeBookService() {
        // TODO code application logic here
		
        
        tmp.addAssignment(1, "project1", 100);
        tmp.addAssignment(2, "project2", 200);
        tmp.addAssignment(3, "project3", 300);

        tmp.addStudent(5551,"fname1", "lname1");
        tmp.addStudent(5552,"fname2", "lname2");
        tmp.addStudent(5553,"fname3", "lname3");

        tmp.getStudent(5551).addGrade(2, 55);
        tmp.getStudent(5551).addGrade(3, 155);
        tmp.getStudent(5551).addGrade(1, 255);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getCourse")
    public Course getCourse() {
        //TODO write your implementation code here:
        return tmp;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getAssignments")
    public String getAssignments(@WebParam(name= "name")int i) {
        //TODO write your implementation code here:
    //   arraylist[] assign = tmp.getAssignments();
    //    return assign;
    String AssignOutput = "Id " + tmp.getAssignment(i).getId() +" Description " + tmp.getAssignment(i).getDescription() +" maxscore " + tmp.getAssignment(i).getMaxScore(); 
    return  AssignOutput;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getStudent")
    public String getStudent(@WebParam(name= "name")int i, int d ) {
    Student student = tmp.getStudent(i);
    String studentOutput = "Id " + tmp.getStudent(i).getStudentID() +" fname " + tmp.getStudent(i).getFname() +" lname " + tmp.getStudent(i).getLname() + " grade " + student.getGrade(d).getScore(); 
    return studentOutput;

    }
    /**
     * Web service operation
     */
    @WebMethod(operationName = "changeName")
    public String changeName(@WebParam(name = "fname") String fname, @WebParam(name = "lname") String lname, @WebParam(name = "ID") int ID) {
        tmp.getStudent(ID).setFname(fname);
        tmp.getStudent(ID).setLname(lname);
        
        return "names changed";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "ChangeGrade")
    public int ChangeGrade(@WebParam(name = "StuId") int StuId, @WebParam(name = "AssignID") int AssignID, @WebParam(name = "NewGrade") int NewGrade) {
        tmp.getStudent(StuId).getGrade(AssignID).setScore(NewGrade);
        return 0;
    }

    /**
     * Web service operation
     */
    

  
    




}
