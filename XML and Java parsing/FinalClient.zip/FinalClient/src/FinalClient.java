
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pdc49_000
 */
public class FinalClient {
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("hello enter the number what you want to do"); 
        
 System.out.println("1. Print the assignments (ID, description and max score)");
System.out.println ("2. Print the students (ID, first name, last name, and the grades)");
System.out.println("3. Change student's first and last name");
System.out.println("4. Change a student's grade");

//listen for user input
//Student stu = getStudentID(1);
                
      //  System.out.println("Frist: " + emp.getFanme() + " Last" + emp.getLname());

Scanner scanner = new Scanner(System.in);
 int input = scanner.nextInt();
 System.out.println("your choice is" + input);
//switch statments

//handler (input)
if (input ==1)
{
    
    System.out.println("enter assignment id");
    
    int id =scanner.nextInt();
    String printOut = getAssignments(id);
    System.out.println(printOut);
}
else if (input ==2)
{
    
   
 System.out.println(" enter Student id");
    
    int id =scanner.nextInt();
    System.out.println ("enter assignment id");
    int assignId =scanner.nextInt();
    String printOut = getStudent(id,assignId);
    System.out.println(printOut);
}
else if (input ==3)
{
      System.out.println ("Enter new first name");
    String fname =scanner.next();
     System.out.println ("Enter new last name");
    String lname =scanner.next();
     System.out.println(" enter Student id");
    int id =scanner.nextInt();
    String printOut = changeName(fname,lname,id);
    System.out.println(printOut);
}
else if (input ==4)
{
   
     System.out.println(" enter Student id");
    int id =scanner.nextInt();
     System.out.println(" assignment id");
    int assignId =scanner.nextInt();
      System.out.println(" enter newgrade");
    int newGrade =scanner.nextInt();
    int printOut = changeGrade(id,assignId,newGrade);
    System.out.println(printOut);
}

    }

    private static String getAssignments(int name) {
        edu.bradley.cis445.service.GradeBookService_Service service = new edu.bradley.cis445.service.GradeBookService_Service();
        edu.bradley.cis445.service.GradeBookService port = service.getGradeBookServicePort();
        return port.getAssignments(name);
    }

    private static String changeName(java.lang.String fname, java.lang.String lname, int id) {
        edu.bradley.cis445.service.GradeBookService_Service service = new edu.bradley.cis445.service.GradeBookService_Service();
        edu.bradley.cis445.service.GradeBookService port = service.getGradeBookServicePort();
        return port.changeName(fname, lname, id);
    }

    private static int changeGrade(int stuId, int assignID, int newGrade) {
        edu.bradley.cis445.service.GradeBookService_Service service = new edu.bradley.cis445.service.GradeBookService_Service();
        edu.bradley.cis445.service.GradeBookService port = service.getGradeBookServicePort();
        return port.changeGrade(stuId, assignID, newGrade);
    }

    private static String getStudent(int name, int arg1) {
        edu.bradley.cis445.service.GradeBookService_Service service = new edu.bradley.cis445.service.GradeBookService_Service();
        edu.bradley.cis445.service.GradeBookService port = service.getGradeBookServicePort();
        return port.getStudent(name, arg1);
    }
    
}
